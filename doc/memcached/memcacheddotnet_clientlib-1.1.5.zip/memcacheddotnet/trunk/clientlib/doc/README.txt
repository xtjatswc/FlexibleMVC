The documentation on how to use this code is in the code files.

See the MemcachedBench project for good example code.